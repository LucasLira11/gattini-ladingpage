import { createFileRoute } from "@tanstack/react-router";
import { Nav } from "@/components/site/Nav";
import { Hero } from "@/components/site/Hero";
import { About } from "@/components/site/About";
import { Specialties } from "@/components/site/Specialties";
import { Differentials } from "@/components/site/Differentials";
import { Gallery } from "@/components/site/Gallery";
import { Team } from "@/components/site/Team";
import { CTA } from "@/components/site/CTA";
import { Footer } from "@/components/site/Footer";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Clínica Gattini — Psicologia premium, escuta humanizada" },
      { name: "description", content: "Um espaço seguro, elegante e acolhedor para o seu bem-estar emocional. Psicologia premium em São Paulo." },
      { property: "og:title", content: "Clínica Gattini — Psicologia premium" },
      { property: "og:description", content: "Cuidar da mente também é um ato de sofisticação." },
      { property: "og:type", content: "website" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <main className="bg-background text-foreground">
      <Nav />
      <Hero />
      <About />
      <Specialties />
      <Differentials />
      <Gallery />
      <Team />
      <CTA />
      <Footer />
    </main>
  );
}
