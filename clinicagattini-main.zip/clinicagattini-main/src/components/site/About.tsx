import { Reveal } from "./Reveal";

export function About() {
  return (
    <section id="sobre" className="py-32 md:py-44 relative">
      <div className="mx-auto max-w-6xl px-6 md:px-10 grid md:grid-cols-12 gap-16 items-start">
        <Reveal className="md:col-span-4">
          <span className="text-[11px] tracking-[0.28em] uppercase text-taupe">01 — A clínica</span>
        </Reveal>

        <div className="md:col-span-8 space-y-10">
          <Reveal>
            <h2 className="font-display text-4xl md:text-5xl lg:text-6xl leading-[1.08] text-cocoa text-balance">
              Um espaço pensado para o tempo lento da escuta onde cada detalhe foi
              <em className="italic text-taupe"> desenhado para acolher.</em>
            </h2>
          </Reveal>

          <Reveal delay={0.1}>
            <p className="text-[15px] leading-[1.85] text-taupe max-w-2xl">
              Na Clínica Gattini, acreditamos que o cuidado emocional é uma forma refinada
              de respeito por si mesmo. Trabalhamos com escuta humanizada, sigilo absoluto e
              um acompanhamento construído à medida da sua história — em um ambiente que
              convida ao silêncio, à pausa e ao reencontro.
            </p>
          </Reveal>

          <Reveal delay={0.2}>
            <div className="grid sm:grid-cols-3 gap-10 pt-10 border-t border-border">
              {[
                { n: "20+", l: "anos de experiência clínica" },
                { n: "3", l: "psicólogos especialistas" },
                { n: "100%", l: "atendimento sigiloso" },
              ].map((s) => (
                <div key={s.l}>
                  <div className="font-display text-4xl text-cocoa">{s.n}</div>
                  <div className="mt-2 text-[12px] tracking-[0.14em] uppercase text-taupe">{s.l}</div>
                </div>
              ))}
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
