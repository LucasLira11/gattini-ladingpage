import { motion } from "framer-motion";
import heroImg from "@/assets/hero-clinic.jpg";

const ease = [0.22, 1, 0.36, 1] as const;

export function Hero() {
  return (
    <section id="top" className="relative pt-32 md:pt-40 pb-24 md:pb-32 overflow-hidden">
      <div className="mx-auto max-w-7xl px-6 md:px-10 grid lg:grid-cols-12 gap-12 lg:gap-16 items-center">
        <div className="lg:col-span-6 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease, delay: 0.2 }}
            className="flex items-center gap-3 mb-8"
          >
            <span className="h-px w-10 bg-taupe/60" />
            <span className="text-[11px] tracking-[0.28em] uppercase text-taupe">Psicologia · Desde 2000</span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.4, ease, delay: 0.3 }}
            className="font-display text-[44px] sm:text-6xl lg:text-7xl leading-[1.02] text-cocoa text-balance"
          >
            Cuidar da mente <br />
            também é um <em className="italic text-taupe">ato de sofisticação.</em>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.2, ease, delay: 0.55 }}
            className="mt-8 max-w-md text-[15px] leading-[1.7] text-taupe text-pretty"
          >
            Um espaço seguro, elegante e acolhedor pensado para que o seu bem-estar
            emocional seja vivido com a serenidade que ele merece.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease, delay: 0.75 }}
            className="mt-10 flex flex-wrap items-center gap-5"
          >
            <a
              href="#agendar"
              className="group inline-flex items-center gap-3 bg-cocoa text-background px-8 py-4 rounded-full
                text-[12px] tracking-[0.22em] uppercase hover:bg-taupe transition-all duration-700"
            >
              Agendar consulta
              <span className="inline-block transition-transform duration-500 group-hover:translate-x-1">→</span>
            </a>
            <a
              href="#sobre"
              className="text-[12px] tracking-[0.22em] uppercase text-taupe hover:text-cocoa transition-colors duration-500
                border-b border-taupe/30 hover:border-cocoa pb-1"
            >
              Conhecer a clínica
            </a>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 1.04 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.8, ease }}
          className="lg:col-span-6 relative"
        >
          <div className="relative aspect-[4/5] overflow-hidden rounded-[28px] shadow-card">
            <img
              src={heroImg}
              alt="Interior elegante e minimalista da Clínica Gattini com poltrona em linho e luz natural"
              width={1080}
              height={1350}
              className="h-full w-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-tr from-cocoa/15 via-transparent to-transparent" />
          </div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.2, ease, delay: 1 }}
            className="absolute -left-4 md:-left-10 bottom-10 backdrop-blur-md bg-background/70
              border border-border rounded-2xl px-6 py-5 shadow-soft max-w-[240px]"
          >
            <div className="font-display italic text-2xl text-cocoa leading-tight">silêncio,</div>
            <div className="font-display italic text-2xl text-taupe leading-tight">acolhimento,</div>
            <div className="font-display italic text-2xl text-cocoa leading-tight">presença.</div>
          </motion.div>
        </motion.div>
      </div>

      <div className="absolute -top-40 -right-40 w-[520px] h-[520px] rounded-full bg-accent/40 blur-3xl opacity-50 pointer-events-none" />
    </section>
  );
}
