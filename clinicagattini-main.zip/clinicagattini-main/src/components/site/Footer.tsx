export function Footer() {
  return (
    <footer className="bg-background border-t border-border">
      <div className="mx-auto max-w-7xl px-6 md:px-10 py-20 grid md:grid-cols-12 gap-12">
        <div className="md:col-span-5">
          <div className="font-display text-3xl text-cocoa">GATTINI</div>
          <p className="mt-6 text-[14px] leading-[1.75] text-taupe max-w-sm">
            Escuta humanizada e ambientes pensados para o
            cuidado emocional contemporâneo.
          </p>
        </div>

        <div className="md:col-span-3">
          <div className="text-[11px] tracking-[0.22em] uppercase text-taupe mb-5">Contato</div>
          <ul className="space-y-2 text-[14px] text-cocoa">
            <li>email@clinicagattini.com</li>
            <li>+55 (31) 4002-8922</li>
            <li>Seg — Sex · 08h às 21h | Sáb · 08h às 13h</li>
          </ul>
        </div>

        <div className="md:col-span-2">
          <div className="text-[11px] tracking-[0.22em] uppercase text-taupe mb-5">Endereço</div>
          <p className="text-[14px] leading-[1.75] text-cocoa">
            Av. Prudente de Morais, 840 - Sala 702<br />Coracao de Jesus · Belo Horizonte
          </p>
        </div>

        <div className="md:col-span-2">
          <div className="text-[11px] tracking-[0.22em] uppercase text-taupe mb-5">Social</div>
          <ul className="space-y-2 text-[14px] text-cocoa">
            <li><a href="#" className="hover:text-taupe transition-colors duration-500">Instagram</a></li>
          </ul>
        </div>
      </div>

      <div className="border-t border-border">
        <div className="mx-auto max-w-7xl px-6 md:px-10 py-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-[11px] tracking-[0.18em] uppercase text-taupe">
            © {new Date().getFullYear()} Clínica Gattini · Todos os direitos reservados
          </div>
          <div className="text-[11px] tracking-[0.18em] uppercase text-taupe">
            CRP · Conselho Regional de Psicologia
          </div>
        </div>
      </div>
    </footer>
  );
}
