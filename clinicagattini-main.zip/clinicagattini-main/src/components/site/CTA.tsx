import { Reveal } from "./Reveal";

const getScheduleWhatsAppLink = () => {
  const message = "Estou interessado em agendar uma consulta normal sem especificar nenhum profissional";
  const encodedMessage = encodeURIComponent(message);
  return `https://wa.me/5522997793222?text=${encodedMessage}`;
};

const getDirectWhatsAppLink = () => {
  return "https://wa.me/5522997793222";
};

export function CTA() {
  return (
    <section id="agendar" className="py-40 md:py-56 relative overflow-hidden bg-cocoa text-background">
      <div className="absolute inset-0 grain pointer-events-none" />
      <div className="mx-auto max-w-4xl px-6 md:px-10 text-center relative">
        <Reveal>
          <span className="text-[11px] tracking-[0.32em] uppercase text-background/60">Comece sua jornada</span>
        </Reveal>
        <Reveal delay={0.1}>
          <h2 className="mt-8 font-display text-5xl md:text-7xl lg:text-8xl leading-[1.02] text-background text-balance">
            Seu espaço seguro <br />
            para <em className="italic text-accent">evoluir</em> começa aqui.
          </h2>
        </Reveal>
        <Reveal delay={0.2}>
          <p className="mt-10 max-w-xl mx-auto text-[15px] leading-[1.8] text-background/70">
            Reserve sua primeira consulta. Responderemos em até 24 horas, com a
            discrição e o cuidado que você merece.
          </p>
        </Reveal>
        <Reveal delay={0.3}>
          <div className="mt-12 flex flex-wrap justify-center gap-5">
            <a href={getScheduleWhatsAppLink()} className="group inline-flex items-center gap-3 bg-background text-cocoa px-10 py-5 rounded-full
              text-[12px] tracking-[0.22em] uppercase hover:bg-accent transition-all duration-700">
              Agendar consulta
              <span className="transition-transform duration-500 group-hover:translate-x-1">→</span>
            </a>
            <a href={getDirectWhatsAppLink()} className="text-[12px] tracking-[0.22em] uppercase text-background/70 hover:text-background
              border-b border-background/30 hover:border-background pb-1 transition-colors duration-500 self-center">
              Falar pelo WhatsApp
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
