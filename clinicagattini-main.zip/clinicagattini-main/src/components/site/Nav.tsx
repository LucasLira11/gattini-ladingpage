import { motion } from "framer-motion";

const links = [
  { href: "#sobre", label: "Sobre" },
  { href: "#especialidades", label: "Especialidades" },
  { href: "#ambiente", label: "Ambiente" },
  { href: "#equipe", label: "Equipe" },
];

export function Nav() {
  return (
    <motion.header
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
      className="fixed top-0 inset-x-0 z-50"
    >
      <div className="mx-auto max-w-7xl px-6 md:px-10 py-5 flex items-center justify-between
        backdrop-blur-md bg-background/60 border-b border-border/40">
        <a href="#top" className="flex items-baseline gap-2">
          <span className="font-display text-2xl tracking-tight text-cocoa">GATTINI</span>
        </a>
        <nav className="hidden md:flex items-center gap-10">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="text-[13px] tracking-[0.12em] uppercase text-taupe hover:text-cocoa transition-colors duration-500"
            >
              {l.label}
            </a>
          ))}
        </nav>
        <a
          href="#agendar"
          className="text-[12px] tracking-[0.18em] uppercase border border-cocoa/30 px-5 py-2.5 rounded-full
            text-cocoa hover:bg-cocoa hover:text-background transition-all duration-700"
        >
          Agendar
        </a>
      </div>
    </motion.header>
  );
}
