import { Reveal } from "./Reveal";
import p1 from "@/assets/psy-1.jpeg";
import p2 from "@/assets/psy-2.jpeg";
import p3 from "@/assets/psy-3.jpg";

const team = [
  { img: p1, name: "Dr. Carlos Gattini", spec: "Fundador · TCC", bio: "Mais de 20 anos dedicados à escuta de processos profundos de transformação pessoal." },
  { img: p2, name: "Dra. Júlia Gattini", spec: "Terapia Cognitiva", bio: "Especialista em ansiedade, burnout e construção de fronteiras emocionais saudáveis." },
  { img: p3, name: "Dra. Marina Castelli", spec: "Relacionamentos & Vínculos", bio: "Trabalha a maturidade afetiva e a construção consciente de relações duradouras." },
];

const getWhatsAppLink = (professionalName: string) => {
  const message = `Olá, quero ver a disponibilidade dos horários de consulta com ${professionalName}`;
  const encodedMessage = encodeURIComponent(message);
  return `https://wa.me/5522997793222?text=${encodedMessage}`;
};

export function Team() {
  return (
    <section id="equipe" className="py-32 md:py-44">
      <div className="mx-auto max-w-7xl px-6 md:px-10">
        <div className="grid md:grid-cols-12 gap-12 mb-20">
          <Reveal className="md:col-span-4">
            <span className="text-[11px] tracking-[0.28em] uppercase text-taupe">05 — Equipe</span>
          </Reveal>
          <Reveal className="md:col-span-8">
            <h2 className="font-display text-4xl md:text-5xl lg:text-6xl leading-[1.08] text-cocoa text-balance">
              Profissionais que <em className="italic text-taupe">honram</em> a sua história.
            </h2>
          </Reveal>
        </div>

        <div className="grid md:grid-cols-3 gap-8 md:gap-10">
          {team.map((m, i) => (
            <Reveal key={m.name} delay={i * 0.08}>
              <article className="group">
                <div className="aspect-[4/5] overflow-hidden rounded-[24px] mb-6 bg-secondary">
                  <img src={m.img} alt={m.name} width={768} height={960} loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-[1400ms] ease-out group-hover:scale-[1.03]" />
                </div>
                <div className="text-[11px] tracking-[0.22em] uppercase text-taupe mb-2">{m.spec}</div>
                <h3 className="font-display text-2xl text-cocoa mb-3">{m.name}</h3>
                <p className="text-[14px] leading-[1.75] text-taupe mb-6">{m.bio}</p>
                <a href={getWhatsAppLink(m.name)}
                  className="inline-flex items-center gap-2 text-[11px] tracking-[0.22em] uppercase text-cocoa
                    border-b border-cocoa/40 hover:border-cocoa pb-1 transition-colors duration-500">
                  Agendar consulta <span className="transition-transform duration-500 group-hover:translate-x-1">→</span>
                </a>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
