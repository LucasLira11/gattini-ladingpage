import { Reveal } from "./Reveal";

function Icon({ name }: { name: string }) {
  const common = "w-7 h-7 stroke-cocoa";
  switch (name) {
    case "heart":
      return <svg className={common} viewBox="0 0 24 24" fill="none" strokeWidth="1"><path d="M12 20s-7-4.5-7-10a4 4 0 017-2.6A4 4 0 0119 10c0 5.5-7 10-7 10z"/></svg>;
    case "leaf":
      return <svg className={common} viewBox="0 0 24 24" fill="none" strokeWidth="1"><path d="M20 4s-9 0-13 4-4 12-4 12 8 0 12-4 5-12 5-12zM4 20L14 10"/></svg>;
    case "lock":
      return <svg className={common} viewBox="0 0 24 24" fill="none" strokeWidth="1"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 018 0v3"/></svg>;
    case "compass":
      return <svg className={common} viewBox="0 0 24 24" fill="none" strokeWidth="1"><circle cx="12" cy="12" r="9"/><path d="M15 9l-2 5-5 2 2-5z"/></svg>;
    case "diamond":
      return <svg className={common} viewBox="0 0 24 24" fill="none" strokeWidth="1"><path d="M12 3l9 7-9 11L3 10z"/></svg>;
    default:
      return null;
  }
}

const items = [
  { i: "heart", t: "Atendimento humanizado", d: "Escuta atenta, tempo generoso e presença real em cada sessão." },
  { i: "leaf", t: "Ambiente acolhedor", d: "Interiores serenos pensados para induzir o estado de cuidado." },
  { i: "lock", t: "Sigilo e confiança", d: "Privacidade absoluta como princípio inegociável do nosso trabalho." },
  { i: "compass", t: "Acompanhamento personalizado", d: "Cada percurso terapêutico é desenhado à medida da sua história." },
  { i: "diamond", t: "Experiência premium", d: "Da recepção ao processo clínico, o refinamento está em cada detalhe." },
];

export function Differentials() {
  return (
    <section className="py-32 md:py-44">
      <div className="mx-auto max-w-7xl px-6 md:px-10">
        <div className="grid md:grid-cols-12 gap-12 mb-20">
          <Reveal className="md:col-span-4">
            <span className="text-[11px] tracking-[0.28em] uppercase text-taupe">03 — Diferenciais</span>
          </Reveal>
          <Reveal className="md:col-span-8">
            <h2 className="font-display text-4xl md:text-5xl lg:text-6xl leading-[1.08] text-cocoa text-balance">
              O que torna a Gattini uma <em className="italic text-taupe">experiência única.</em>
            </h2>
          </Reveal>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-x-12 gap-y-16">
          {items.map((it, i) => (
            <Reveal key={it.t} delay={i * 0.06}>
              <div className="space-y-5">
                <Icon name={it.i} />
                <div className="hairline w-12" />
                <h3 className="font-display text-2xl text-cocoa">{it.t}</h3>
                <p className="text-[14px] leading-[1.75] text-taupe">{it.d}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
