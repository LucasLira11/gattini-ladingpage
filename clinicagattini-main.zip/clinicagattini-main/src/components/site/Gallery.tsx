import { Reveal } from "./Reveal";
import g1 from "@/assets/gallery-1.jpg";
import g2 from "@/assets/gallery-2.jpg";
import g3 from "@/assets/gallery-3.jpg";

export function Gallery() {
  return (
    <section id="ambiente" className="py-32 md:py-44 bg-secondary/40">
      <div className="mx-auto max-w-7xl px-6 md:px-10">
        <div className="grid md:grid-cols-12 gap-12 mb-20">
          <Reveal className="md:col-span-4">
            <span className="text-[11px] tracking-[0.28em] uppercase text-taupe">04 — Ambiente</span>
          </Reveal>
          <Reveal className="md:col-span-8">
            <h2 className="font-display text-4xl md:text-5xl lg:text-6xl leading-[1.08] text-cocoa text-balance">
              Um espaço onde a <em className="italic text-taupe">arquitetura</em> também é terapêutica.
            </h2>
          </Reveal>
        </div>

        <div className="grid grid-cols-12 gap-4 md:gap-6">
          <Reveal className="col-span-12 md:col-span-7">
            <div className="aspect-[4/5] overflow-hidden rounded-[24px] group">
              <img src={g1} alt="Poltrona em linho com luz natural" width={1024} height={1280} loading="lazy"
                className="h-full w-full object-cover transition-transform duration-[1400ms] ease-out group-hover:scale-[1.03]" />
            </div>
          </Reveal>
          <div className="col-span-12 md:col-span-5 flex flex-col gap-4 md:gap-6">
            <Reveal delay={0.1}>
              <div className="aspect-[5/4] overflow-hidden rounded-[24px] group">
                <img src={g2} alt="Sala de espera minimalista" width={1280} height={1024} loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-[1400ms] ease-out group-hover:scale-[1.03]" />
              </div>
            </Reveal>
            <Reveal delay={0.2}>
              <div className="aspect-[5/6] overflow-hidden rounded-[24px] group">
                <img src={g3} alt="Corredor com porta em madeira clara" width={1024} height={1280} loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-[1400ms] ease-out group-hover:scale-[1.03]" />
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
