import { Reveal } from "./Reveal";

const items = [
  { n: "I", t: "Ansiedade", d: "Ferramentas para reencontrar a calma e habitar o presente com mais leveza." },
  { n: "II", t: "Terapia Individual", d: "Um percurso íntimo de escuta, autoconhecimento e transformação." },
  { n: "III", t: "Relacionamentos", d: "Vínculos mais conscientes — consigo, com o outro e com o mundo." },
  { n: "IV", t: "Burnout", d: "Recuperar energia, sentido e fronteiras saudáveis com o trabalho." },
  { n: "V", t: "Desenvolvimento Emocional", d: "Maturidade afetiva como uma prática contínua e refinada." },
  { n: "VI", t: "Autoconhecimento", d: "Habitar a própria história com clareza, ternura e coragem." },
];

export function Specialties() {
  return (
    <section id="especialidades" className="py-32 md:py-44 bg-secondary/40">
      <div className="mx-auto max-w-7xl px-6 md:px-10">
        <div className="grid md:grid-cols-12 gap-12 mb-20">
          <Reveal className="md:col-span-4">
            <span className="text-[11px] tracking-[0.28em] uppercase text-taupe">02 — Especialidades</span>
          </Reveal>
          <Reveal className="md:col-span-8">
            <h2 className="font-display text-4xl md:text-5xl lg:text-6xl leading-[1.08] text-cocoa text-balance">
              Cuidados <em className="italic text-taupe">pensados</em> para cada momento da sua vida.
            </h2>
          </Reveal>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-px bg-border/60 rounded-[24px] overflow-hidden">
          {items.map((it, i) => (
            <Reveal key={it.t} delay={i * 0.05}>
              <article className="group h-full bg-background p-10 md:p-12 transition-colors duration-700 hover:bg-card">
                <div className="font-display italic text-sm text-taupe mb-12">{it.n}</div>
                <h3 className="font-display text-3xl text-cocoa mb-4">{it.t}</h3>
                <p className="text-[14px] leading-[1.75] text-taupe">{it.d}</p>
                <div className="mt-10 inline-flex items-center gap-2 text-[11px] tracking-[0.22em] uppercase text-cocoa
                  opacity-0 group-hover:opacity-100 transition-opacity duration-700">
                  Saber mais <span className="transition-transform duration-500 group-hover:translate-x-1">→</span>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
